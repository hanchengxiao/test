package org.springframework.context.groovy

beans = {
	framework String, 'Grails'
	foo String, 'hello'
}
