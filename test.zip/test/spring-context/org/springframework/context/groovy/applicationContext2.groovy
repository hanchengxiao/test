package org.springframework.context.groovy

beans {
	company String, 'SpringSource'
}
