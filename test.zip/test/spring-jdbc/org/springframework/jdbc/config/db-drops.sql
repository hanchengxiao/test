drop table T_TEST;
