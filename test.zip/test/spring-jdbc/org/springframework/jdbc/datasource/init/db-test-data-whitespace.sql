insert into T_TEST (NAME) values ('Keith')
/

insert into T_TEST (NAME) values ('Dave')
/
