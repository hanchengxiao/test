insert into T_TEST (NAME) values ('Keith');
insert into T_TEST (NAME) values ('Dave');
select NAME from T_TEST where NAME = 'Keith';
