/* This is a multi line comment
 * The next comment line has no text 

 * The next comment line starts with a space.
 *  x, y, z... 
 */

INSERT INTO users(first_name, last_name) VALUES('Juergen', 'Hoeller');
-- This is also a comment.
/* 
 * Let's add another comment
 * that covers multiple lines
 */INSERT INTO
users(first_name, last_name)
VALUES( 'Sam'     -- first_name
      , 'Brannen' -- last_name
);--