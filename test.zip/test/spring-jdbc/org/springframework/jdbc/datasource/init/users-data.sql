INSERT INTO
users(first_name, last_name)
values('Sam', 'Brannen');
