{*
	these are custom block comments
*}
drop table T_TEST if exists;

{*
	these are custom block comments
*}
create table T_TEST (NAME varchar(50) not null);