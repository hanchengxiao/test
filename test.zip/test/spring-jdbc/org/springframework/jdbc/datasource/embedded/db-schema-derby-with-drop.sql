drop table T_TEST;

create table T_TEST (NAME varchar(50) not null);